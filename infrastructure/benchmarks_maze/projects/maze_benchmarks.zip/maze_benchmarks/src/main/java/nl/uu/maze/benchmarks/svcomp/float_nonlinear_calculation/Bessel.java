//
// SV-COMP property:
//    verification entry point: check()
//    * should not give an assertion-error
//    * should not throw run-time exception
//
// This is a modification of an SV-COMP verification task of the same name.
// Below is a copy of the original notice:
// 


//This file is part of the SV-Benchmarks collection of verification tasks:
//https://gitlab.com/sosy-lab/benchmarking/sv-benchmarks
//
//SPDX-FileCopyrightText: 2024 The SV-Benchmarks Community
//
//SPDX-License-Identifier: Apache-2.0

/*
* This benchmark task is a modification of the following original Benchmark:
* Origin of the benchmark:
*     repo: https://github.com/SymbolicPathFinder/jpf-symbc
*     branch: master
*     root directory: src/examples/concolic
* The benchmark was taken from the repo: 8 October 2024
*/
/*
* Copyright (C) 2014, United States Government, as represented by the
* Administrator of the National Aeronautics and Space Administration.
* All rights reserved.
*
* Symbolic Pathfinder (jpf-symbc) is licensed under the Apache License,
* Version 2.0 (the "License"); you may not use this file except
* in compliance with the License. You may obtain a copy of the License at
*
*        http://www.apache.org/licenses/LICENSE-2.0.
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package nl.uu.maze.benchmarks.svcomp.float_nonlinear_calculation;

public class Bessel {

	static double bessely0test(double x) {
	    if (x == 1.0) return 0.08825696421567698;
	    if (x == 1.25) return 0.2582168515945408;
	    if (x == 1.5) return 0.38244892379775897;
	    if (x == 1.75) return 0.465492628646906;
	    if (x == 2.0) return 0.5103756726497451;
	    if (x == 2.25) return 0.5200647624572782;
	    if (x == 2.5) return 0.49807035961523183;
	    if (x == 2.75) return 0.4486587215691319;
	    if (x == 3.0) return 0.3768500100127904;
	    if (x == 3.25) return 0.2882869026730871;
	    return 1.0;
	  }
	
	public static boolean check(double x) {
		 double y;
		 y = bessely0test(x);
		 if (x < 1.25 || y > 0.2)
			 return true ;
		 throw new AssertionError("SVCOMP positive assertion violated!") ;
	}

}
