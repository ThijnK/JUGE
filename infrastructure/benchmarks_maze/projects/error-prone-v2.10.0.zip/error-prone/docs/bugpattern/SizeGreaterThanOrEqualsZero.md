A standard means of checking non-emptiness of an array or collection is to test
if the size of that collection is greater than 0. However, one may accidentally
check if the size is greater than or equal to 0, which is always true.
