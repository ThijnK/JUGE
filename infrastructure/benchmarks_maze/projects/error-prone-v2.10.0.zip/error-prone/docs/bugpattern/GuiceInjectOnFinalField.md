From the [Guice wiki][wiki]:

> Injecting `final` fields is not recommended because the injected value may not
> be visible to other threads.

[wiki]: https://github.com/google/guice/wiki/InjectionPoints#how-guice-injects
