A declaration has the `@deprecated` Javadoc tag but no `@Deprecated` annotation.
Please add an `@Deprecated` annotation to this declaration in addition to the
`@deprecated` tag in the Javadoc.
