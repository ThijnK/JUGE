Primitives can never be null.
