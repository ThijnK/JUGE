An element can be qualified by at most one qualifier.
