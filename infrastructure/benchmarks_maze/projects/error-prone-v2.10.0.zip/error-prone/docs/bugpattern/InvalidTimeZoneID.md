TimeZone.getTimeZone(String) silently returns GMT when an invalid time zone
identifier is passed in.
