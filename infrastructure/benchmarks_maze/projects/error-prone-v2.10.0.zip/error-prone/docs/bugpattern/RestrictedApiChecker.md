Calls to APIs marked @RestrictedApi are prohibited without a corresponding
allowlist annotation.
