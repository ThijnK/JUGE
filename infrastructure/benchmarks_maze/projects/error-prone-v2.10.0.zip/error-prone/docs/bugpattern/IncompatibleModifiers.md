The @IncompatibleModifiers annotation declares that the target annotation is
incompatible with a set of provided modifiers. This check ensures that all
annotations respect their @IncompatibleModifiers specifications.
