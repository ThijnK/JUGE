The exception is created with `new`, but is not thrown, and the reference is
lost.

Creating an exception without using it is unlikely to be correct, so we assume
that you wanted to throw the exception.
