A `Comparator` is an object that knows how to compare other objects, whereas an
object implementing `Comparable` knows how to compare itself to other objects of
the same type.
