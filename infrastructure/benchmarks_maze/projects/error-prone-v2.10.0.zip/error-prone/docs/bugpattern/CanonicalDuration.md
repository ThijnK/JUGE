Prefer to express durations using the largest possible unit, e.g.
`Duration.ofDays(1)` instead of `Duration.ofSeconds(86400)`.
