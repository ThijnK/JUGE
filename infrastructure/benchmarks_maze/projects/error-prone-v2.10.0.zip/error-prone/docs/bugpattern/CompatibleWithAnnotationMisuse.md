The `@CompatibleWith` annotation is used to mark parameters that need extra type
checking on arguments passed to the method. The annotation was not appropriately
placed on a parameter with a valid type argument. See the javadoc for more
details.
