StringBuilder does not have a char constructor, so instead this code creates a
StringBuilder with initial size equal to the code point of the specified char.
