The Thread is created with `new`, but is never started and is not otherwise
captured.

Threads must be started with `start()` to actually execute.
