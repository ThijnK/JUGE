When you pass a primitive array as the only argument to a varargs method, the
primitive array is autoboxed into a single-element Object array. This is usually
not what was intended.
