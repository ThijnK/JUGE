`Log.isLoggable(tag, level)` throws an `IllegalArgumentException` if its tag
argument is more than 23 characters long.
