If a boolean is enforced to have a certain value in an if statement and then
used as part of a condition within the block, it is redundant.

To fix the problem, replace the variable with `true` in inner statement.
