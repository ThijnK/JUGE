`throwIfUnchecked(knownCheckedException)` is a no-op (aside from performing a
null check). `propagateIfPossible(knownCheckedException)` is a complete no-op.
