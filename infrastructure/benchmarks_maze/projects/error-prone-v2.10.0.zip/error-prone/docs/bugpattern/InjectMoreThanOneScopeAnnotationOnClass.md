Annotating a class with more than one scope annotation is invalid according to
the JSR-330 specification.
