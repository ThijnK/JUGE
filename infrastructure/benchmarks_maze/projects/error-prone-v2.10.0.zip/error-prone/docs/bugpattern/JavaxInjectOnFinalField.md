According to the JSR-330 spec, the @javax.inject.Inject annotation cannot go on
final fields.
