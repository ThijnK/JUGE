Increment operators in method calls are dubious and while argument lists are
evaluated left-to-right, documentation suggests that code not rely on this
specification. In addition, code is clearer when each expression contains at
most one side effect.
