This code will cause a runtime arithmetic exception if it is executed.
