Constructors never return null.
