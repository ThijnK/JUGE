void-returning methods cannot return null.
