Guice `@Provides` methods annotate methods that are used as a means of declaring
bindings. However, this is only helpful inside of a module. Methods outside of
these modules are not used for binding declaration.
