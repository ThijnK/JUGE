Methods with the @LockMethod annotation are expected to acquire one or more
locks. The caller will hold the locks when the function finishes execution.
