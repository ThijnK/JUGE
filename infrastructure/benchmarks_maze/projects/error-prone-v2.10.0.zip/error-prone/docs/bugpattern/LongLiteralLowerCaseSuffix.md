A long literal can have a suffix of 'L' or 'l', but the former is less likely to
be confused with a '1' in most fonts.
