An inner class should be static unless it references members of its enclosing
class. An inner class that is made non-static unnecessarily uses more memory and
does not make the intent of the class clear.
