From documentation: DoubleMath.fuzzyEquals is not transitive, so it is not
suitable for use in Object#equals implementations.
