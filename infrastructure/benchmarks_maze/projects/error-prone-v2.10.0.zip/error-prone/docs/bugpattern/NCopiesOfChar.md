Calling `nCopies('a', 10)` returns a list with 97 copies of 10, not a list with
10 copies of 'a'.
