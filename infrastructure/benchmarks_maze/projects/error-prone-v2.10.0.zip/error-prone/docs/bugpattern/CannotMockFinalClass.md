Mockito cannot mock final classes. See
https://github.com/mockito/mockito/wiki/FAQ for details.
