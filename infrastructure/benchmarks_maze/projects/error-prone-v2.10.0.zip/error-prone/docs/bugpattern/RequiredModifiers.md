This annotation is itself annotated with @RequiredModifiers and can only be used
when the specified modifiers are present. You are attempting touse it on an
element that is missing one or more required modifiers.
