Mixing @Inject and @AssistedInject leads to confusing code and the documentation
specifies not to do it. See
https://google.github.io/guice/api-docs/latest/javadoc/com/google/inject/assistedinject/AssistedInject.html
