.equals() to the same object will result in infinite recursion
