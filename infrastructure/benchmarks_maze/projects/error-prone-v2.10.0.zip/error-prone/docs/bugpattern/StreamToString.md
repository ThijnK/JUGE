The `toString` method on a `Stream` will print its identity, such as
`java.util.stream.ReferencePipeline$Head@6d06d69c`. This is rarely what was
intended.
