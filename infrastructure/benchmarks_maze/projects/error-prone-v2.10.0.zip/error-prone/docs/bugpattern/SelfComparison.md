The arguments to compareTo method are the same object, so it always returns 0.
Either change the arguments to point to different objects or substitute 0.
