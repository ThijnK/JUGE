Scoping annotations are not inherited. They will have no effect if added to an
abstract type.
