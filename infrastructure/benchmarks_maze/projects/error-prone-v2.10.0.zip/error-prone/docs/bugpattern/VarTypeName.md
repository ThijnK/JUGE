As of JDK 10 `var` is a restricted local variable type and cannot be used for
type declarations (see [JEP 286][]).

[JEP 286]: http://openjdk.java.net/jeps/286
