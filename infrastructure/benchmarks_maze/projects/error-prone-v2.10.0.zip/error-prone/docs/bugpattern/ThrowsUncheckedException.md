[Effective Java 3rd Edition §74][ej3e-74] says:

> Use the Javadoc `@throws` tag to document each exception that a method can
> throw, but do *not* use the `throws` keyword on unchecked exceptions.

[ej3e-74]: https://books.google.com/books?id=BIpDDwAAQBAJ
