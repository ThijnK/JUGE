An if statement contains an empty statement as the then clause. A semicolon may
have been inserted by accident.
