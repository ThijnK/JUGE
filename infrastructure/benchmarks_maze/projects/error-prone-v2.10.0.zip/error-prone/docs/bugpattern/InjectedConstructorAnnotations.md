The constructor is annotated with @Inject(optional=true), or it is annotated
with @Inject and a binding annotation. This will cause a Guice runtime error.

See [https://code.google.com/p/google-guice/wiki/InjectionPoints] for details.
