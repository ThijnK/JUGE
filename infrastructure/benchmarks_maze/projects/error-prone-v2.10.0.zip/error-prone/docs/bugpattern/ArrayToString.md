The `toString` method on an array will print its identity, such as
`[I@4488aabb`. This is almost never needed. Use `Arrays.toString` to print a
human-readable summary.
