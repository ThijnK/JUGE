AutoValue constructors are synthesized with their parameters in the same order
as the abstract accessor methods. Calls to the constructor need to match this
ordering.
