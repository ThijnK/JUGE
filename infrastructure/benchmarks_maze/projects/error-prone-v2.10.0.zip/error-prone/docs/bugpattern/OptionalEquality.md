Optionals should be compared for value equality using `.equals()`, and not for
reference equality using `==` and `!=`.
