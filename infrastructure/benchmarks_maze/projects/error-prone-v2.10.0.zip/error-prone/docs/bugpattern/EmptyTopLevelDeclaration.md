A semi-colon at the top level of a Java file is treated as an empty type
declaration in the grammar, but it's confusing and unnecessary.
