Many logging tools build a string representation out of getMessage() and ignores
toString() completely.
