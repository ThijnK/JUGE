Using @AssistedInject and @Inject on the same constructor is a runtimeerror in
Guice.
