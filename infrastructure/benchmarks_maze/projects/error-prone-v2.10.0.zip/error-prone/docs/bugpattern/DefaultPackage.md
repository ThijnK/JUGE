Declaring classes in the default package is discouraged.
