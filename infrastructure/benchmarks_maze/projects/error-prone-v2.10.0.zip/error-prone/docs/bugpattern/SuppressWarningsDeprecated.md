To suppress warnings to deprecated methods, you should add the annotation
`@SuppressWarnings("deprecation")` and not `@SuppressWarnings("deprecated")`
