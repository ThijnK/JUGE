Calling getAnnotation on an annotation that does not have its Retention set to
RetentionPolicy.RUNTIME will always return null.
