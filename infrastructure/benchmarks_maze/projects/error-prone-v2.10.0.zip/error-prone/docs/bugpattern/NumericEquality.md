Numbers are compared for reference equality/inequality using == or != instead of
for value equality using .equals()
